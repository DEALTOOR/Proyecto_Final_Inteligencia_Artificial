from flask import Flask, request, render_template #Para conectar el back y el front
import json
import pandas as pd #De uso general en todos los algoritmos
import numpy as np #De uso general
import matplotlib.pyplot as plt #De uso general
from apyori import apriori #Para el algoritmo apriori
from scipy.spatial.distance import cdist    # Para el cálculo de distancias
from scipy.spatial import distance #Para distancias
from sklearn.preprocessing import StandardScaler, MinMaxScaler  #Para estandarizar los datos
import scipy.cluster.hierarchy as shc #Para cluster jerarquico
from sklearn.cluster import AgglomerativeClustering #Para culster jerarquico
import seaborn as sns
import io
import base64 #Para poder mandar imagenes o figuras al front
import os
from kneed import KneeLocator 
from mpl_toolkits.mplot3d import Axes3D #imprimir imagen en 3d
from sklearn.cluster import KMeans #Algoritmo k-means
from sklearn.metrics import pairwise_distances_argmin_min
import yfinance as yf #Para arboles de pronostico
from sklearn import model_selection
from sklearn.tree import DecisionTreeRegressor #Para solo arboles
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score #Estas 3 son para osques y arboles de pronostico
from sklearn.tree import plot_tree #Imprimir arboles y bosques
from sklearn.tree import export_text#Para mostrar los reporter
from sklearn.ensemble import RandomForestRegressor #Solo para bosques de pronostico
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier#Las 4 ultimas para arboles de clasificacion
from sklearn.ensemble import RandomForestClassifier #Para bosques de clasificacion
from sklearn.preprocessing import label_binarize #La usamos para ver el rendimiento del bosque de clasificiacion
from sklearn.metrics import roc_curve, auc #Para la curva de ROC
from sklearn import linear_model #Modelo logistico
from sklearn.metrics import RocCurveDisplay

fusion_app = Flask(__name__) #App main de Flask

# Obtener la ruta absoluta del directorio actual
base_path = os.path.abspath(os.path.dirname(__file__))
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del index
@fusion_app.route('/')
def index_template():
    return render_template("index.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front del algoritmo apriori
@fusion_app.route('/apriori')
def apriori_template():
    return render_template("apriori.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front del algoritmo de distancias
@fusion_app.route('/distancias')
def distancias_template():
    return render_template("distancias.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front del algoritmo de cluster jerarquico
@fusion_app.route('/clusterJerarquico')
def clusterJerarquico_template():
    return render_template("clusterJerarquico.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front del cluster particional
@fusion_app.route('/clusterParticional')
def clusterParticional_template():
    return render_template("clusterParticional.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front de arboles de pronostico
@fusion_app.route('/arbolPronostico')
def arbolPronostico_template():
    return render_template("arbolPronostico.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front de bosques de pronostico
@fusion_app.route('/bosquePronostico')
def bosquePronostico_template():
    return render_template("bosquePronostico.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front de arboles de clasificacion
@fusion_app.route('/arbolClasificacion')
def arbolClasificacion_template():
    return render_template("arbolClasificacion.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front de bosques de clasificacion
@fusion_app.route('/bosqueClasificacion')
def bosqueClasificacion_template():
    return render_template("bosqueClasificacion.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del front de modelo Logístico
@fusion_app.route('/modeloLogistico')
def modeloLogistico_template():
    return render_template("modeloLogistico.html")
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta del back del algoritmo apriori
@fusion_app.route('/upload_apri', methods=['POST'])
def upload_apriori():
    #Obtenemos los datos del usuario:
    min_support = float(request.form.get('supp'))
    min_confidence = float(request.form.get('conf'))
    min_lift = float(request.form.get('lift'))
    file = request.files['file']
    #Guardamos y analizamos la BD:
    DatosTransacciones = pd.read_csv(file, header=None)
    Transacciones = DatosTransacciones.values.reshape(-1).tolist()
    Lista = pd.DataFrame(Transacciones)
    Lista['Frecuencia'] = 1
    Lista = Lista.groupby(by=[0], as_index=False).count().sort_values(by=['Frecuencia'], ascending=True)
    Lista['Porcentaje'] = (Lista['Frecuencia'] / Lista['Frecuencia'].sum())
    Lista = Lista.rename(columns={0: 'Item'})

    #Mostramos la gráfica de frecuencia de los items
    plt.figure(figsize=(16,20), dpi=300)
    plt.ylabel('Item')
    plt.xlabel('Frecuencia')
    plt.barh(Lista['Item'], width=Lista['Frecuencia'], color='blue')

    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

    #Aplicamos al algoritmo apriori
    TransaccionesLista = DatosTransacciones.stack().groupby(level=0).apply(list).tolist()
    ReglasC1 = apriori(TransaccionesLista, min_support=min_support, min_confidence=min_confidence, min_lift=min_lift)
    ResultadosC1 = list(ReglasC1)
    total_reglas = len(ResultadosC1)

    #Damos formato a las reglas encontradas para el front
    reglas = ""
    for item in ResultadosC1:
        # El primer índice de la lista
        Emparejar = item[0]
        items = [x for x in Emparejar]
        reglas += "<p><strong>Regla:</strong> " + str(item[0]) + "</p>"

        # El segundo índice de la lista
        reglas += "<p><strong>Soporte:</strong> " + str(item[1]) + "</p>"

        # El tercer índice de la lista
        reglas += "<p><strong>Confianza:</strong> " + str(item[2][0][2]) + "</p>"
        reglas += "<p><strong>Elevación:</strong> " + str(item[2][0][3]) + "</p>"
        reglas += "<hr>"

    #Mandamos los resultados obtenidos al front
    return render_template('apriori.html', image_base64=image_base64, total_rules=total_reglas, rulesAp = reglas)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Ruta para el back del algoritmo de distancias
@fusion_app.route('/upload_dist', methods=['POST'])
def upload_distancia():
    file = request.files['file']
    distancia = request.form['distancia']
    # Guardamos la BD
    BD_Distancias = pd.read_csv(file)
    # Estandarizamos la BD
    estandarizar = StandardScaler()
    MEstandarizada = estandarizar.fit_transform(BD_Distancias)
    
    # Calculamos las columnas de la BD de acuerdo a la distancia escogida por el usuario
    Dist = cdist(MEstandarizada, MEstandarizada, metric=distancia)
    MDist = pd.DataFrame(Dist)
    
    # Calculamos las 10 primeras columnas de la BD de acuerdo a la distancia escogida por el usuario
    Dist10 = cdist(MEstandarizada[0:10], MEstandarizada[0:10], metric=distancia)
    MDist10 = pd.DataFrame(Dist10)

    # Convierte la matriz de distancias en una lista de listas para enviar al frontend
    MDist_values = MDist.values.tolist()
    
    # Convierte la matriz de distancias de 10 en una lista de listas para enviar al frontend
    MDist_values10 = MDist10.values.tolist()

    # Envía el resultado al frontend
    return render_template('distancias.html', MDist_values=MDist_values, MDist_values10 = MDist_values10)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
# Ruta para el back del algoritmo de cluster
@fusion_app.route("/upload_clustJ", methods=["POST"])
def upload_clusteJ():
    file = request.files["file"]
    num_clusters = int(request.form.get('num_clus'))
    BD_Cluster = pd.read_csv(file)
    # Excluir la columna "id" del cálculo de correlación
    BD_Cluster = BD_Cluster.drop('IDNumber', axis=1)
    BD_Cluster = BD_Cluster.drop('Diagnosis', axis=1)
    # Obtener la matriz de correlaciones de las columnas restantes
    CorrB = BD_Cluster.corr(method='pearson')

    #Mapa de calor 
    plt.figure(figsize = (14,7) )
    MatrizInf = np.triu(CorrB)
    sns.heatmap(CorrB, cmap = 'RdBu_r', annot = True, mask = MatrizInf)
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_calor = base64.b64encode(buffer.getvalue()).decode("utf-8")

    #Trabajaremos con las variables con mayor dependencia 
    MatrizVariables = np.array(BD_Cluster [['Perimeter', 'Area', 'ConcavePoints', 'Concavity', 'Compactness', 'Texture']])
    pd.DataFrame(MatrizVariables)
    #Estandarizamos los datos
    # Crear una instancia de StandardScaler
    estandarizar = StandardScaler()
    # Ajustar y transformar la matriz de variables
    MEstandarizada = estandarizar.fit_transform(MatrizVariables)
    # Crear un DataFrame con la matriz estandarizada
    pd.DataFrame(MEstandarizada)

    #CLUSTER ASCENDENTE JERÁRQUICO
    plt.figure(figsize=(10,7))
    plt.title("Pacientes con cáncer de mama")  # Corregido el nombre de la función
    plt.xlabel("Observaciones")
    plt.ylabel("Distancia")

    Arbol = shc.dendrogram(shc.linkage(MEstandarizada, method='complete', metric='euclidean'))
     # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_arbol= base64.b64encode(buffer.getvalue()).decode("utf-8")

    #Aplicamos el algoritmo
    MJerarquico = AgglomerativeClustering(n_clusters=num_clusters, linkage='complete', affinity='euclidean')
    MJerarquico.fit_predict(MEstandarizada)
    MJerarquico.labels_
    #Creamos la columna para clusterH
    BD_Cluster['clusterH'] = MJerarquico.labels_
    #Agrupamos por clusterH
    BD_Cluster.groupby(['clusterH'])['clusterH'].count()
    #Mantenemos solo los registros con clusterH = 1
    BD_Cluster[BD_Cluster['clusterH'] == 1]
    #Creamos los centroides
    CentroidesH = BD_Cluster.groupby(['clusterH'])[['Perimeter', 'Area', 'ConcavePoints', 'Concavity', 'Compactness', 'Texture']].mean()
    CentroidesH = CentroidesH.values.tolist()
    #Obtenemos la gráfica del agrupamiento
    plt.figure(figsize = (10,7))
    plt.scatter(MEstandarizada[:,0], MEstandarizada[:,1], c=MJerarquico.labels_)
    plt.grid()
     # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_cluster = base64.b64encode(buffer.getvalue()).decode("utf-8")

    # Envía el resultado al frontend
    return render_template(
        "clusterJerarquico.html", image_base64_calor=image_base64_calor,
        image_base64_arbol=image_base64_arbol,
        image_base64_cluster=image_base64_cluster,
        CentroidesH = CentroidesH)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#CLUSTER PARTICIONAL
@fusion_app.route("/upload_clustP", methods=["POST"])
def upload_clusterP():
    file = request.files["file"]
    num_clusters = int(request.form.get('num_clus'))
    BD_Cluster = pd.read_csv(file)
    # Excluir la columna "id" del cálculo de correlación
    BD_Cluster = BD_Cluster.drop('IDNumber', axis=1)
    BD_Cluster = BD_Cluster.drop('Diagnosis', axis=1)
    # Obtener la matriz de correlaciones de las columnas restantes
    CorrB = BD_Cluster.corr(method='pearson')

    #Mapa de calor 
    plt.figure(figsize = (14,7) )
    MatrizInf = np.triu(CorrB)
    sns.heatmap(CorrB, cmap = 'RdBu_r', annot = True, mask = MatrizInf)
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_calor = base64.b64encode(buffer.getvalue()).decode("utf-8")

    #Trabajaremos con las variables con mayor dependencia 
    MatrizVariables = np.array(BD_Cluster [['Perimeter', 'Area', 'ConcavePoints', 'Concavity', 'Compactness', 'Texture']])
    pd.DataFrame(MatrizVariables)
    #Estandarizamos los datos
    # Crear una instancia de StandardScaler
    estandarizar = StandardScaler()
    # Ajustar y transformar la matriz de variables
    MEstandarizada = estandarizar.fit_transform(MatrizVariables)
    # Crear un DataFrame con la matriz estandarizada
    pd.DataFrame(MEstandarizada)

    # CLUSTER PARTICIONAL K-MEANS
    SSE = []
    for i in range(2, 12):
        km = KMeans(n_clusters=i, random_state=0)
        km.fit(MEstandarizada)
        SSE.append(km.inertia_)

    plt.figure(figsize=(10, 7))
    plt.plot(range(2, 12), SSE, marker='o')
    plt.xlabel('Cantidad de clusters k')
    plt.ylabel('SSE')
    plt.title('Elbow Method')

    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_codo = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # Aplicamos el algoritmo k-means sobre la matriz estandarizada:
    MParticional = KMeans(n_clusters=num_clusters, random_state=0).fit(MEstandarizada)
    MParticional.predict(MEstandarizada)

    # Agregamos la columna 'clusterP'
    BD_Cluster['clusterP'] = MParticional.labels_

    # Generamos los centroides
    CentroidesP = BD_Cluster.groupby(['clusterP'])[['Texture', 'Area', 'Smoothness', 'Compactness', 'Symmetry', 'FractalDimension']].mean()
    CentroidesP = CentroidesP.values.tolist()
    # Obtenemos la gráfica de los clusters en 3D
    plt.rcParams['figure.figsize'] = (10, 7)
    plt.style.use('ggplot')
    colors = ['red', 'blue', 'green', 'yellow', 'orange']
    assign = []

    for row in MParticional.labels_:
        assign.append(colors[row])

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(
        MEstandarizada[:, 0],
        MEstandarizada[:, 1],
        MEstandarizada[:, 2],
        marker='o',
        c=assign,
        s=60
    )

    ax.scatter(
        MParticional.cluster_centers_[:, 0],
        MParticional.cluster_centers_[:, 1],
        MParticional.cluster_centers_[:, 2],
        marker='o',
        c=colors,
        s=1400
    )

    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_cluster3D = base64.b64encode(buffer.getvalue()).decode('utf-8')

    # Envía el resultado al frontend
    return render_template(
        "clusterParticional.html", image_base64_calor=image_base64_calor,
        image_base64_codo=image_base64_codo,
        image_base64_cluster3D=image_base64_cluster3D, 
        CentroidesP=CentroidesP)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Back para arboles de pronostico
@fusion_app.route('/upload_arbolProno', methods=['POST'])
def upload_arbolProno():
    ticker = request.form['ticker']
    maxD = int(request.form['max_depth'])
    minS = int(request.form['split'])
    minL = int(request.form['leaf'])
    feIni = request.form['inicio']
    feFin = request.form['fin']
    intervalo = "1d"
    Data = yf.Ticker(ticker)
    info = Data.info
    nombre = info['longName']#Estas 2 lineas son para obtener el nombre de la compañia en base a su ticker
    Hist = Data.history(start = feIni, end = feFin, interval=intervalo)
    
    #Obtenemos la gráfica del precio de las acciones
    plt.figure(figsize=(20, 5))
    plt.plot(Hist['Open'], color='purple', marker='+', label='Open')
    plt.plot(Hist['High'], color='blue', marker='+', label='High')
    plt.plot(Hist['Low'], color='orange', marker='+', label='Low')
    plt.plot(Hist['Close'], color='green', marker='+', label='Close')
    plt.xlabel('Fecha')
    plt.ylabel('Precio de las acciones')
    plt.title(nombre)
    plt.grid(True)
    plt.legend()
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_precioAcciones= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    MatrizDatos = Hist.drop(columns = ['Volume', 'Dividends', 'Stock Splits'])#Dropeanmos esas columnas
    MatrizDatos = MatrizDatos.dropna()#Dropeamos valores nulos
    
    #Variables predictorias
    X = np.array(MatrizDatos[['Open',
                     'High',
                     'Low']])
    
    #Variable a pronosticar
    Y = np.array(MatrizDatos[['Close']])
    
    #Division de los datos
    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(X, Y, 
                                                                    test_size = 0.2, 
                                                                    random_state = 0, 
                                                                    shuffle = True)
    #Se crea el pronostico con unj arbol de decision
    PronosticoAD = DecisionTreeRegressor(max_depth=maxD, min_samples_split=minS, min_samples_leaf=minL, random_state=0)
    PronosticoAD.fit(X_train, Y_train)
    
    #Se genera el pronostico
    Y_Pronostico = PronosticoAD.predict(X_test)
    
    Valores = pd.DataFrame(Y_test, Y_Pronostico)
    
    criterio = PronosticoAD.criterion
    importancia_variables = PronosticoAD.feature_importances_
    mae = mean_absolute_error(Y_test, Y_Pronostico)
    mse = mean_squared_error(Y_test, Y_Pronostico)
    rmse = mean_squared_error(Y_test, Y_Pronostico, squared=False)
    score = r2_score(Y_test, Y_Pronostico)
    cadena1 = f"Se tiene un Score de {str(score)}, que indica que el pronóstico del precio de cierre de la acción se logrará con un {str(score*100)} por ciento de efectividad."
    cadena2 = f"Además, los pronósticos del modelo final se alejan en promedio {str(mse)} y {str(rmse)} unidades del valor real, esto es, MSE y RMSE, respectivamente."
    
    modelo = ""
    modelo += "<p><strong>Criterio:</strong> " + str(criterio) + "</p>"
    modelo += "<p><strong>Importancia de las variables:</strong> " + str(importancia_variables) + "</p>"
    modelo += "<p><strong>MAE:</strong> " + str(mae) + "</p>"
    modelo += "<p><strong>MSE:</strong> " + str(mse) + "</p>"
    modelo += "<p><strong>RMSE:</strong> " + str(rmse) + "</p>"
    modelo += "<p><strong>Score:</strong> " + str(score) + "</p>"
    modelo += "<p>"+ cadena1 +"</p>"
    modelo += "<p>"+ cadena2 +"</p>"
    modelo += "<hr>"
    #Pronostico de las acciones
    plt.figure(figsize=(20, 5))
    plt.plot(Y_test, color='red', marker='+', label='Real')
    plt.plot(Y_Pronostico, color='green', marker='+', label='Estimado')
    plt.xlabel('Fecha')
    plt.ylabel('Precio de las acciones')
    plt.title('Pronóstico de las acciones de ' + nombre)
    plt.grid(True)
    plt.legend()
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_pronosticoAcciones= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    Importancia = pd.DataFrame({'Variable': list(MatrizDatos[['Open', 'High', 'Low']]),
                            'Importancia': PronosticoAD.feature_importances_}).sort_values('Importancia', ascending=False)
    #Arbol de pronostico
    plt.figure(figsize=(16,16))  
    plot_tree(PronosticoAD, feature_names = ['Open', 'High', 'Low'])
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_arbolPronostico= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    
    Reporte = export_text(PronosticoAD, feature_names = ['Open', 'High', 'Low'])
    # Envía el resultado al frontend
    return render_template('arbolPronostico.html', image_base64_precioAcciones=image_base64_precioAcciones,
                           modelo=modelo,image_base64_pronosticoAcciones=image_base64_pronosticoAcciones,
                           image_base64_arbolPronostico=image_base64_arbolPronostico, Reporte=Reporte)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
#Back para bosques de pronostico
@fusion_app.route('/upload_bosqueProno', methods=['POST'])
def upload_bosqueProno():
    ticker = request.form['ticker']
    maxD = int(request.form['max_depth'])
    minS = int(request.form['split'])
    minL = int(request.form['leaf'])
    feIni = request.form['inicio']
    feFin = request.form['fin']
    intervalo = "1d"
    Data = yf.Ticker(ticker)
    info = Data.info
    nombre = info['longName']#Estas 2 lineas son para obtener el nombre de la compañia en base a su ticker
    Hist = Data.history(start = feIni, end = feFin, interval=intervalo)
    
    #Obtenemos la gráfica del precio de las acciones
    plt.figure(figsize=(20, 5))
    plt.plot(Hist['Open'], color='purple', marker='+', label='Open')
    plt.plot(Hist['High'], color='blue', marker='+', label='High')
    plt.plot(Hist['Low'], color='orange', marker='+', label='Low')
    plt.plot(Hist['Close'], color='green', marker='+', label='Close')
    plt.xlabel('Fecha')
    plt.ylabel('Precio de las acciones')
    plt.title(nombre)
    plt.grid(True)
    plt.legend()
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_precioAcciones= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    MatrizDatos = Hist.drop(columns = ['Volume', 'Dividends', 'Stock Splits'])#Dropeanmos esas columnas
    MatrizDatos = MatrizDatos.dropna()#Dropeamos valores nulos
    
    #Variables predictorias
    X = np.array(MatrizDatos[['Open',
                     'High',
                     'Low']])
    
    #Variable a pronosticar
    Y = np.array(MatrizDatos[['Close']])
    
    #Division de los datos
    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(X, Y, 
                                                                    test_size = 0.2, 
                                                                    random_state = 0, 
                                                                    shuffle = True)
    #Se crea el pronostico con unj arbol de decision
    PronosticoBA = RandomForestRegressor(n_estimators=105,max_depth=maxD, min_samples_split=minS, min_samples_leaf=minL, random_state=0)
    PronosticoBA.fit(X_train, Y_train)
    
    #Se genera el pronostico
    Y_Pronostico = PronosticoBA.predict(X_test)
    
    Valores = pd.DataFrame(Y_test, Y_Pronostico)
    
    criterio = PronosticoBA.criterion
    importancia_variables = PronosticoBA.feature_importances_
    mae = mean_absolute_error(Y_test, Y_Pronostico)
    mse = mean_squared_error(Y_test, Y_Pronostico)
    rmse = mean_squared_error(Y_test, Y_Pronostico, squared=False)
    score = r2_score(Y_test, Y_Pronostico)
    cadena1 = f"Se tiene un Score de {str(score)}, que indica que el pronóstico del precio de cierre de la acción se logrará con un {str(score*100)} por ciento de efectividad."
    cadena2 = f"Además, los pronósticos del modelo final se alejan en promedio {str(mse)} y {str(rmse)} unidades del valor real, esto es, MSE y RMSE, respectivamente."
    
    modelo = ""
    modelo += "<p><strong>Criterio:</strong> " + str(criterio) + "</p>"
    modelo += "<p><strong>Importancia de las variables:</strong> " + str(importancia_variables) + "</p>"
    modelo += "<p><strong>MAE:</strong> " + str(mae) + "</p>"
    modelo += "<p><strong>MSE:</strong> " + str(mse) + "</p>"
    modelo += "<p><strong>RMSE:</strong> " + str(rmse) + "</p>"
    modelo += "<p><strong>Score:</strong> " + str(score) + "</p>"
    modelo += "<p>"+ cadena1 +"</p>"
    modelo += "<p>"+ cadena2 +"</p>"
    modelo += "<hr>"
    
    #Pronostico de las acciones
    plt.figure(figsize=(20, 5))
    plt.plot(Y_test, color='red', marker='+', label='Real')
    plt.plot(Y_Pronostico, color='green', marker='+', label='Estimado')
    plt.xlabel('Fecha')
    plt.ylabel('Precio de las acciones')
    plt.title('Pronóstico de las acciones de ' + nombre)
    plt.grid(True)
    plt.legend()
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_pronosticoAcciones= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    Importancia = pd.DataFrame({'Variable': list(MatrizDatos[['Open', 'High', 'Low']]),
                            'Importancia': PronosticoBA.feature_importances_}).sort_values('Importancia', ascending=False)
    
    Estimador = PronosticoBA.estimators_[50]
    #Arbol de pronostico
    plt.figure(figsize=(16,16))  
    plot_tree(Estimador, feature_names = ['Open', 'High', 'Low'])
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_bosquePronostico= base64.b64encode(buffer.getvalue()).decode('utf-8')
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
    Reporte = export_text(Estimador, feature_names = ['Open', 'High', 'Low'])
    # Envía el resultado al frontend
    return render_template('bosquePronostico.html', image_base64_precioAcciones=image_base64_precioAcciones,
                           modelo=modelo,image_base64_pronosticoAcciones=image_base64_pronosticoAcciones,
                           image_base64_bosquePronostico=image_base64_bosquePronostico, Reporte=Reporte)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------
# Ruta para el back del algoritmo de arboles de clasificacion
@fusion_app.route("/upload_arbolClasi", methods=["POST"])
def upload_arbolClasi():
    file = request.files["file"]
    maxD = int(request.form['max_depth'])
    minS = int(request.form['split'])
    minL = int(request.form['leaf'])
    BD = pd.read_csv(file)

    #Mapa de calor para ver las correlaciones
    plt.figure(figsize=(14,7))
    MatrizInf = np.triu(BD.corr())
    sns.heatmap(BD.corr(), cmap='RdBu_r', annot=True, mask=MatrizInf)
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_calor = base64.b64encode(buffer.getvalue()).decode("utf-8")

    #Variables predictoras
    X = np.array(BD[['baseline value',
                            'accelerations',
                            'fetal_movement',
                            'uterine_contractions',
                            'light_decelerations',
                            'severe_decelerations',
                            'prolongued_decelerations',
                            'abnormal_short_term_variability',
                            'mean_value_of_short_term_variability',
                            'percentage_of_time_with_abnormal_long_term_variability',
                            'mean_value_of_long_term_variability',
                            'histogram_width',
                            'histogram_min',
                            'histogram_max',
                            'histogram_number_of_peaks',
                            'histogram_number_of_zeroes', 
                            'histogram_mode',
                            'histogram_mean',
                            'histogram_median',
                            'histogram_variance',
                            'histogram_tendency']])
    pd.DataFrame(X)
    
    #Variable clase
    Y = np.array(BD[['fetal_health']])
    pd.DataFrame(Y)

    #Creacion de los modelos
    X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, 
                                                                                test_size = 0.2, 
                                                                                random_state = 0,
                                                                                shuffle = True)
    #Aplicamos el algoritmo
    ClasificacionAD = DecisionTreeClassifier(max_depth=maxD, min_samples_split=minS, min_samples_leaf=minL, random_state=0)
    ClasificacionAD.fit(X_train, Y_train)
    
    #Clasificación final 
    Y_ClasificacionAD = ClasificacionAD.predict(X_validation)
    
    ValoresMod1 = pd.DataFrame(Y_validation, Y_ClasificacionAD)
    #Obtenemos la exactitud
    accuracy = accuracy_score(Y_validation, Y_ClasificacionAD)
    
    #Matriz de clasificación
    ModeloClasificacion1 = ClasificacionAD.predict(X_validation)
    Matriz_Clasificacion1 = pd.crosstab(Y_validation.ravel(), 
                                    ModeloClasificacion1, 
                                    rownames=['Actual'], 
                                    colnames=['Clasificación']) 
    
    ImportanciaMod1 = pd.DataFrame({'Variable': list(BD[['baseline value',
                                                              'accelerations',
                                                              'fetal_movement',
                                                              'uterine_contractions',
                                                              'light_decelerations',
                                                              'severe_decelerations',
                                                              'prolongued_decelerations',
                                                              'abnormal_short_term_variability',
                                                              'mean_value_of_short_term_variability',
                                                              'percentage_of_time_with_abnormal_long_term_variability',
                                                              'mean_value_of_long_term_variability',
                                                              'histogram_width',
                                                              'histogram_min',
                                                              'histogram_max',
                                                              'histogram_number_of_peaks',
                                                              'histogram_number_of_zeroes',
                                                              'histogram_mode',
                                                              'histogram_mean',
                                                              'histogram_median',
                                                              'histogram_variance',
                                                              'histogram_tendency']]),
                                'Importancia': ClasificacionAD.feature_importances_}).sort_values('Importancia', ascending=False)
    #Se imprime el arbol
    plt.figure(figsize=(16,16))  
    plot_tree(ClasificacionAD, 
            feature_names = ['baseline value',
                            'accelerations',
                            'fetal_movement',
                            'uterine_contractions',
                            'light_decelerations',
                            'severe_decelerations',
                            'prolongued_decelerations',
                            'abnormal_short_term_variability',
                            'mean_value_of_short_term_variability',
                            'percentage_of_time_with_abnormal_long_term_variability',
                            'mean_value_of_long_term_variability',
                            'histogram_width',
                            'histogram_min',
                            'histogram_max',
                            'histogram_number_of_peaks',
                            'histogram_number_of_zeroes',
                            'histogram_mode',
                            'histogram_mean',
                            'histogram_median',
                            'histogram_variance',
                            'histogram_tendency'],
            class_names = ['1', '2', '3'])

    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_arbolClasificacion= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    Reporte = export_text(ClasificacionAD, feature_names = ['baseline value',
                                                        'accelerations',
                                                        'fetal_movement',
                                                        'uterine_contractions',
                                                        'light_decelerations',
                                                        'severe_decelerations',
                                                        'prolongued_decelerations',
                                                        'abnormal_short_term_variability',
                                                        'mean_value_of_short_term_variability',
                                                        'percentage_of_time_with_abnormal_long_term_variability',
                                                        'mean_value_of_long_term_variability',
                                                        'histogram_width',
                                                        'histogram_min',
                                                        'histogram_max',
                                                        'histogram_number_of_peaks',
                                                        'histogram_number_of_zeroes',
                                                        'histogram_mode',
                                                        'histogram_mean',
                                                        'histogram_median',
                                                        'histogram_variance',
                                                        'histogram_tendency'])
    # Envía el resultado al frontend
    return render_template(
        "arbolClasificacion.html", image_base64_calor=image_base64_calor, accuracy=accuracy,
        image_base64_arbolClasificacion=image_base64_arbolClasificacion, Reporte=Reporte)
#----------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------
# Ruta para el back del algoritmo de arboles de clasificacion
@fusion_app.route("/upload_bosqueClasi", methods=["POST"])
def upload_bosqueClasi():
    file = request.files["file"]
    maxD = int(request.form['max_depth'])
    minS = int(request.form['split'])
    minL = int(request.form['leaf'])
    BD = pd.read_csv(file)

    #Mapa de calor para ver las correlaciones
    plt.figure(figsize=(14,7))
    MatrizInf = np.triu(BD.corr())
    sns.heatmap(BD.corr(), cmap='RdBu_r', annot=True, mask=MatrizInf)
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_calor = base64.b64encode(buffer.getvalue()).decode("utf-8")

    #Variables predictoras
    X = np.array(BD[['baseline value',
                            'accelerations',
                            'fetal_movement',
                            'uterine_contractions',
                            'light_decelerations',
                            'severe_decelerations',
                            'prolongued_decelerations',
                            'abnormal_short_term_variability',
                            'mean_value_of_short_term_variability',
                            'percentage_of_time_with_abnormal_long_term_variability',
                            'mean_value_of_long_term_variability',
                            'histogram_width',
                            'histogram_min',
                            'histogram_max',
                            'histogram_number_of_peaks',
                            'histogram_number_of_zeroes', 
                            'histogram_mode',
                            'histogram_mean',
                            'histogram_median',
                            'histogram_variance',
                            'histogram_tendency']])
    pd.DataFrame(X)
    
    #Variable clase
    Y = np.array(BD[['fetal_health']])
    pd.DataFrame(Y)

    #Creacion de los modelos
    X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, 
                                                                                test_size = 0.2, 
                                                                                random_state = 0,
                                                                                shuffle = True)
    #Aplicamos el algoritmo
    ClasificacionBA = RandomForestClassifier(n_estimators=100,max_depth=maxD, min_samples_split=minS, min_samples_leaf=minL, random_state=0)
    ClasificacionBA.fit(X_train, Y_train)
    
    #Clasificación final 
    Y_ClasificacionBA = ClasificacionBA.predict(X_validation)
    
    ValoresMod2 = pd.DataFrame(Y_validation, Y_ClasificacionBA)
    #Obtenemos la exactitud
    accuracy = accuracy_score(Y_validation, Y_ClasificacionBA)
    
    #Matriz de clasificación
    #Matriz de clasificación
    ModeloClasificacion2 = ClasificacionBA.predict(X_validation)
    Matriz_Clasificacion2 = pd.crosstab(Y_validation.ravel(),
                                    ModeloClasificacion2,
                                    rownames=['Reales'],
                                    colnames=['Clasificación']) 
    
    Importancia2 = pd.DataFrame({'Variable': list(BD[['baseline value',
                                                           'accelerations',
                                                           'fetal_movement',
                                                           'uterine_contractions',
                                                           'light_decelerations',
                                                           'severe_decelerations',
                                                           'prolongued_decelerations',
                                                           'abnormal_short_term_variability',
                                                           'mean_value_of_short_term_variability',
                                                           'percentage_of_time_with_abnormal_long_term_variability',
                                                           'mean_value_of_long_term_variability',
                                                           'histogram_width',
                                                           'histogram_min',
                                                           'histogram_max',
                                                           'histogram_number_of_peaks',
                                                           'histogram_number_of_zeroes',
                                                           'histogram_mode',
                                                           'histogram_mean',
                                                           'histogram_median',
                                                           'histogram_variance',
                                                           'histogram_tendency']]), 
                             'Importancia': ClasificacionBA.feature_importances_}).sort_values('Importancia', ascending=False)
    #Se imprime el arbol
    Estimador = ClasificacionBA.estimators_[50]
    plt.figure(figsize=(16,16))  
    plot_tree(Estimador, 
            feature_names = ['baseline value',
                            'accelerations',
                            'fetal_movement',
                            'uterine_contractions',
                            'light_decelerations',
                            'severe_decelerations',
                            'prolongued_decelerations',
                            'abnormal_short_term_variability',
                            'mean_value_of_short_term_variability',
                            'percentage_of_time_with_abnormal_long_term_variability',
                            'mean_value_of_long_term_variability',
                            'histogram_width',
                            'histogram_min',
                            'histogram_max',
                            'histogram_number_of_peaks',
                            'histogram_number_of_zeroes',
                            'histogram_mode',
                            'histogram_mean',
                            'histogram_median',
                            'histogram_variance',
                            'histogram_tendency'],
            class_names = ['1', '2', '3'])

    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_bosqueClasificacion= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    Reporte = export_text(Estimador, feature_names = ['baseline value',
                                                        'accelerations',
                                                        'fetal_movement',
                                                        'uterine_contractions',
                                                        'light_decelerations',
                                                        'severe_decelerations',
                                                        'prolongued_decelerations',
                                                        'abnormal_short_term_variability',
                                                        'mean_value_of_short_term_variability',
                                                        'percentage_of_time_with_abnormal_long_term_variability',
                                                        'mean_value_of_long_term_variability',
                                                        'histogram_width',
                                                        'histogram_min',
                                                        'histogram_max',
                                                        'histogram_number_of_peaks',
                                                        'histogram_number_of_zeroes',
                                                        'histogram_mode',
                                                        'histogram_mean',
                                                        'histogram_median',
                                                        'histogram_variance',
                                                        'histogram_tendency'])
    
    #Rendimiento
    y_score = ClasificacionBA.predict_proba(X_validation)
    y_test_bin = label_binarize(Y_validation, classes=[1, 
                                                    2, 
                                                    3])
    n_classes = y_test_bin.shape[1]
    
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
        plt.plot(fpr[i], tpr[i], color='darkorange', lw=2)
        print('AUC para la clase {}: {}'.format(i+1, auc(fpr[i], tpr[i])))

    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Rendimiento')
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_rendimiento= base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    # Envía el resultado al frontend
    return render_template(
        "bosqueClasificacion.html", image_base64_calor=image_base64_calor, accuracy=accuracy,
        image_base64_bosqueClasificacion=image_base64_bosqueClasificacion, Reporte=Reporte,
        image_base64_rendimiento=image_base64_rendimiento)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------    
#MODELO LOGISTICO
@fusion_app.route("/upload_modeloLogistico", methods=["POST"])
def upload_modeloLogistico():
    file = request.files["file"]
    BD = pd.read_csv(file)
    
    plt.figure(figsize=(10, 7))
    plt.scatter(BD['BloodPressure'], BD['Glucose'], c = BD.Outcome)
    plt.grid()
    plt.xlabel('BloodPressure')
    plt.ylabel('Glucose')
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_dispersion = base64.b64encode(buffer.getvalue()).decode("utf-8")
    
    #Mapa de calor para ver las correlaciones
    plt.figure(figsize=(14,7))
    MatrizInf = np.triu(BD.corr())
    sns.heatmap(BD.corr(), cmap='RdBu_r', annot=True, mask=MatrizInf)
    
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)
    image_base64_calor = base64.b64encode(buffer.getvalue()).decode("utf-8")
    
    #Variables predictoras
    X = np.array(BD[['Pregnancies', 
                        'Glucose', 
                        'BloodPressure', 
                        'SkinThickness', 
                        'Insulin', 
                        'BMI',
                        'DiabetesPedigreeFunction',
                        'Age']])
    
    #Variable clase
    Y = np.array(BD[['Outcome']])
    
    X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, 
                                                                                test_size = 0.2, 
                                                                                random_state = 0,
                                                                                shuffle = True)
    
    #Se entrena el modelo a partir de los datos de entrada
    ClasificacionRL = linear_model.LogisticRegression()
    ClasificacionRL.fit(X_train, Y_train)
    
    #Predicciones probabilísticas
    Probabilidad = ClasificacionRL.predict_proba(X_validation)
    proba = pd.DataFrame(Probabilidad)
    proba = proba.values.tolist()
    
    #Clasificación final 
    Y_ClasificacionRL = ClasificacionRL.predict(X_validation)
    clasificacionRL = print(Y_ClasificacionRL)
    # Convertir la matriz en una cadena de texto
    clasiRL = np.array2string(Y_ClasificacionRL)
    #Obtenemos la exactitud
    accuracy = accuracy_score(Y_validation, Y_ClasificacionRL)
    
    #Matriz de clasificación
    ModeloClasificacion = ClasificacionRL.predict(X_validation)
    Matriz_Clasificacion = pd.crosstab(Y_validation.ravel(), 
                                    ModeloClasificacion, 
                                    rownames=['Reales'], 
                                    colnames=['Clasificación']) 
    
    CurvaROC = RocCurveDisplay.from_estimator(ClasificacionRL, X_validation, Y_validation, name="Diabetes")
    # Guardar la imagen en una variable base64 para mostrarla en el frontend
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64_ROC = base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    # Envía el resultado al frontend
    return render_template(
        "modeloLogistico.html", image_base64_dispersion = image_base64_dispersion,
        image_base64_calor = image_base64_calor, proba = proba, clasiRL = clasiRL,
        accuracy = accuracy, image_base64_ROC = image_base64_ROC)
#----------------------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------------------    
if __name__ == '__main__':
    fusion_app.run(debug=True, port=5100)